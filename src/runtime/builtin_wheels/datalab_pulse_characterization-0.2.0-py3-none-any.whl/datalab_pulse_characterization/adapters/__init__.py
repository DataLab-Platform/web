"""Host adapters."""
