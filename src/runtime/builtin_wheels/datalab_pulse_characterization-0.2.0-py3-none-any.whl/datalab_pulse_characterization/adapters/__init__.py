"""Host adapters."""
