"""Host-specific integration adapters."""
