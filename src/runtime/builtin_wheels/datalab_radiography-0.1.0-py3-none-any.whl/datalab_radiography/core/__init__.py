"""Host-independent domain code."""
