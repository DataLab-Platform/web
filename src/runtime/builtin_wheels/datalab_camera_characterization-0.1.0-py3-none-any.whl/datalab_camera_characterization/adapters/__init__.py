"""Host-specific integration adapters."""
