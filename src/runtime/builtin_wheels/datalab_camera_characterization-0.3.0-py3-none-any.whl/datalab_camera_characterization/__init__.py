"""Camera and detector characterization package."""

PLUGIN_DESCRIPTION = "Characterization of scientific cameras and detectors"
PLUGIN_ID = "org.datalab.camera-characterization"
PLUGIN_NAME = "Camera & Detector Characterization"
__version__ = "0.3.0"

__all__ = [
    "PLUGIN_DESCRIPTION",
    "PLUGIN_ID",
    "PLUGIN_NAME",
    "__version__",
]
